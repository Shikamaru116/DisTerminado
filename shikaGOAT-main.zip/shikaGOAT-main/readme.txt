instala yarn add @react-navigation/native 
instala yarn add react-native-screens react-native-safe-area-context
yarn add @react-navigation/native-stack 




creo que igual el yarn install
ya si no ejecutas

yarn expo install